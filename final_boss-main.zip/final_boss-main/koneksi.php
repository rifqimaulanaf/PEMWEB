<?php
// konfugurasi database
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "db_rental";
// perintah php untuk akses ke database
$koneksi = mysqli_connect($host, $user, $password, $database)
?>
